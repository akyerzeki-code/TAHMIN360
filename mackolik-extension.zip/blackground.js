chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: "https://www.mackolik.com/canli-sonuclar" });
});
